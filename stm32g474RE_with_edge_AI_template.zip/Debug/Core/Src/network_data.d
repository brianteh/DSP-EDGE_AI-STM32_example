Core/Src/network_data.o: ../Core/Src/network_data.c \
 ../Core/Inc/network_data.h ../Core/Inc/stai.h
../Core/Inc/network_data.h:
../Core/Inc/stai.h:
