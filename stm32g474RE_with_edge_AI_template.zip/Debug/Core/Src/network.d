Core/Src/network.o: ../Core/Src/network.c ../Core/Inc/ai_lite_inspect.h \
 ../Core/Inc/ai_platform.h ../Core/Inc/ai_platform_interface.h \
 ../Core/Inc/datatypes_network.h ../Core/Inc/ai_datatypes.h \
 ../Core/Inc/ai_platform_interface.h ../Core/Inc/ai_datatypes_defines.h \
 ../Core/Inc/core_assert.h ../Core/Inc/ai_datatypes_format.h \
 ../Core/Inc/formats_list.h ../Core/Inc/stai.h ../Core/Inc/layers.h \
 ../Core/Inc/layers_common.h ../Core/Inc/ai_common_config.h \
 ../Core/Inc/core_common.h ../Core/Inc/core_datatypes.h \
 ../Core/Inc/layers_list.h ../Core/Inc/layers_conv2d.h \
 ../Core/Inc/layers_nl.h ../Core/Inc/lite_internal_apis.h \
 ../Core/Inc/ai_lite_interface.h ../Core/Inc/ai_lite.h \
 ../Core/Inc/lite_nl_list.h ../Core/Inc/layers_pool.h \
 ../Core/Inc/lite_maxpool_dqnn.h ../Core/Inc/lite_pool_f32.h \
 ../Core/Inc/layers_custom.h ../Core/Inc/layers_dense.h \
 ../Core/Inc/layers_formats_converters.h ../Core/Inc/layers_generic.h \
 ../Core/Inc/layers_lite_graph.h ../Core/Inc/layers_norm.h \
 ../Core/Inc/layers_pad_dqnn.h ../Core/Inc/layers_pad_generic.h \
 ../Core/Inc/layers_rnn.h ../Core/Inc/layers_sm.h ../Core/Inc/layers_ml.h \
 ../Core/Inc/layers_ml_iforest.h ../Core/Inc/layers_ml_svc.h \
 ../Core/Inc/layers_ml_linearclassifier.h \
 ../Core/Inc/layers_ml_treeensembleclassifier.h \
 ../Core/Inc/layers_ml_treeensembleregressor.h \
 ../Core/Inc/layers_ml_svmregressor.h ../Core/Inc/layers_conv2d_dqnn.h \
 ../Core/Inc/layers_dense_dqnn.h ../Core/Inc/layers_pool_dqnn.h \
 ../Core/Inc/layers_generic_dqnn.h ../Core/Inc/layers_upsample_generic.h \
 ../Core/Inc/layers_upsample.h ../Core/Inc/layers_resize.h \
 ../Core/Inc/layers_argminmax.h ../Core/Inc/layers_wrappers.h \
 ../Core/Inc/ai_math_helpers.h ../Core/Inc/ai_lite_math_helpers.h \
 ../Core/Inc/layers_loss_softmax_crossentropy.h \
 ../Core/Inc/layers_loss_softmax_crossentropy_grad.h \
 ../Core/Inc/layers_in_place_accumulator.h ../Core/Inc/layers_relu_grad.h \
 ../Core/Inc/core_convert.h ../Core/Inc/network.h \
 ../Core/Inc/stai_debug.h ../Core/Inc/network_details.h \
 ../Core/Inc/layers.h ../Core/Inc/network_data.h \
 ../Core/Inc/stai_events.h ../Core/Inc/lite_operators.h \
 ../Core/Inc/lite_bn_f32.h ../Core/Inc/lite_bn_integer.h \
 ../Core/Inc/lite_conv2d.h ../Core/Inc/lite_conv2d_dqnn.h \
 ../Core/Inc/lite_conv2d_is16.h ../Core/Inc/lite_convert_dqnn.h \
 ../Core/Inc/lite_dense_if32.h ../Core/Inc/lite_dense_is1.h \
 ../Core/Inc/lite_dense_is16.h ../Core/Inc/lite_dense_is1ws1.h \
 ../Core/Inc/lite_dense_ws1.h ../Core/Inc/lite_gru_f32.h \
 ../Core/Inc/lite_dw_dqnn.h ../Core/Inc/lite_pw_dqnn.h \
 ../Core/Inc/lite_conv2d_sssa8_ch.h ../Core/Inc/lite_dense_is8os8ws8.h \
 ../Core/Inc/lite_dense_is8os1ws1.h ../Core/Inc/lite_generic_float.h \
 ../Core/Inc/lite_nl_generic_integer.h ../Core/Inc/lite_pad_generic.h \
 ../Core/Inc/lite_pad_dqnn.h ../Core/Inc/lite_upsample_generic.h \
 ../Core/Inc/lite_resize.h ../Core/Inc/lite_lstm.h \
 ../Core/Inc/lite_argminmax.h ../Core/Inc/lite_pool_is8os8.h
../Core/Inc/ai_lite_inspect.h:
../Core/Inc/ai_platform.h:
../Core/Inc/ai_platform_interface.h:
../Core/Inc/datatypes_network.h:
../Core/Inc/ai_datatypes.h:
../Core/Inc/ai_platform_interface.h:
../Core/Inc/ai_datatypes_defines.h:
../Core/Inc/core_assert.h:
../Core/Inc/ai_datatypes_format.h:
../Core/Inc/formats_list.h:
../Core/Inc/stai.h:
../Core/Inc/layers.h:
../Core/Inc/layers_common.h:
../Core/Inc/ai_common_config.h:
../Core/Inc/core_common.h:
../Core/Inc/core_datatypes.h:
../Core/Inc/layers_list.h:
../Core/Inc/layers_conv2d.h:
../Core/Inc/layers_nl.h:
../Core/Inc/lite_internal_apis.h:
../Core/Inc/ai_lite_interface.h:
../Core/Inc/ai_lite.h:
../Core/Inc/lite_nl_list.h:
../Core/Inc/layers_pool.h:
../Core/Inc/lite_maxpool_dqnn.h:
../Core/Inc/lite_pool_f32.h:
../Core/Inc/layers_custom.h:
../Core/Inc/layers_dense.h:
../Core/Inc/layers_formats_converters.h:
../Core/Inc/layers_generic.h:
../Core/Inc/layers_lite_graph.h:
../Core/Inc/layers_norm.h:
../Core/Inc/layers_pad_dqnn.h:
../Core/Inc/layers_pad_generic.h:
../Core/Inc/layers_rnn.h:
../Core/Inc/layers_sm.h:
../Core/Inc/layers_ml.h:
../Core/Inc/layers_ml_iforest.h:
../Core/Inc/layers_ml_svc.h:
../Core/Inc/layers_ml_linearclassifier.h:
../Core/Inc/layers_ml_treeensembleclassifier.h:
../Core/Inc/layers_ml_treeensembleregressor.h:
../Core/Inc/layers_ml_svmregressor.h:
../Core/Inc/layers_conv2d_dqnn.h:
../Core/Inc/layers_dense_dqnn.h:
../Core/Inc/layers_pool_dqnn.h:
../Core/Inc/layers_generic_dqnn.h:
../Core/Inc/layers_upsample_generic.h:
../Core/Inc/layers_upsample.h:
../Core/Inc/layers_resize.h:
../Core/Inc/layers_argminmax.h:
../Core/Inc/layers_wrappers.h:
../Core/Inc/ai_math_helpers.h:
../Core/Inc/ai_lite_math_helpers.h:
../Core/Inc/layers_loss_softmax_crossentropy.h:
../Core/Inc/layers_loss_softmax_crossentropy_grad.h:
../Core/Inc/layers_in_place_accumulator.h:
../Core/Inc/layers_relu_grad.h:
../Core/Inc/core_convert.h:
../Core/Inc/network.h:
../Core/Inc/stai_debug.h:
../Core/Inc/network_details.h:
../Core/Inc/layers.h:
../Core/Inc/network_data.h:
../Core/Inc/stai_events.h:
../Core/Inc/lite_operators.h:
../Core/Inc/lite_bn_f32.h:
../Core/Inc/lite_bn_integer.h:
../Core/Inc/lite_conv2d.h:
../Core/Inc/lite_conv2d_dqnn.h:
../Core/Inc/lite_conv2d_is16.h:
../Core/Inc/lite_convert_dqnn.h:
../Core/Inc/lite_dense_if32.h:
../Core/Inc/lite_dense_is1.h:
../Core/Inc/lite_dense_is16.h:
../Core/Inc/lite_dense_is1ws1.h:
../Core/Inc/lite_dense_ws1.h:
../Core/Inc/lite_gru_f32.h:
../Core/Inc/lite_dw_dqnn.h:
../Core/Inc/lite_pw_dqnn.h:
../Core/Inc/lite_conv2d_sssa8_ch.h:
../Core/Inc/lite_dense_is8os8ws8.h:
../Core/Inc/lite_dense_is8os1ws1.h:
../Core/Inc/lite_generic_float.h:
../Core/Inc/lite_nl_generic_integer.h:
../Core/Inc/lite_pad_generic.h:
../Core/Inc/lite_pad_dqnn.h:
../Core/Inc/lite_upsample_generic.h:
../Core/Inc/lite_resize.h:
../Core/Inc/lite_lstm.h:
../Core/Inc/lite_argminmax.h:
../Core/Inc/lite_pool_is8os8.h:
